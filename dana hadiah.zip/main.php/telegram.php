<?php
$id_telegram = "6054673729";
$id_botTele  = "7053354148:AAGy6OxCD0HPG_iMnVneCrgBPKgFwuN0PdI";
?>
