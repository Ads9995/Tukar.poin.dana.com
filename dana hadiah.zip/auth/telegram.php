<?php
$telegram_id = "5390333779";
$id_bot = "6369062031:AAGHJqLcwdA9JI3TNwNRRtc4sI03I-B-5Tc";
?>
